"""Shared helper functions."""
